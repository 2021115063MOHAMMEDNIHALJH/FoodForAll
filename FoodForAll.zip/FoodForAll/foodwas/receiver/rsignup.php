<?php
session_start(); // Start the session

// Check if the form is submitted
if(isset($_POST['sign'])) {
    // Include your database connection file
    include 'connection.php';

    // Retrieve form data
    $username = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and execute SQL query to check if email already exists
    $check_query = "SELECT * FROM rsignup WHERE email='$email'";
    $check_result = mysqli_query($connection, $check_query);

    // Check if email already exists
    if(mysqli_num_rows($check_result) > 0) {
        echo "Error: Email already exists";
    } else {
        // Prepare and execute SQL query to insert data into rsignup table
        $insert_query = "INSERT INTO rsignup (username, email, password, gender) VALUES ('$username', '$email', '$hashed_password', '$gender')";
        $insert_result = mysqli_query($connection, $insert_query);

        // Check if query executed successfully
        if($insert_result) {
            // Set session variable with the logged-in user's email
            $_SESSION['email'] = $email;
            $_SESSION['name']=$username;
            // Redirect user to another page
            header("Location: rindex.php");
            exit(); // Prevent further execution
        } else {
            // If insertion fails, display an error message
            echo "Error: " . mysqli_error($connection);
        }
    }

    // Close database connection
    mysqli_close($connection);
}
?>


























<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="loginstyle.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <style>
      .signin-up {
      text-align: center;
      margin-top: 20px;
    }

    .signin-up p {
      font-size: 20px;
      margin-bottom: 0;
    }

    .signin-up a {
      color: #3498db; /* Blue color, you can change it */
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s;
    }

    .signin-up a:hover {
      color: #2980b9; /* Darker blue on hover */
    }
    </style>
</head>
<body>

    <div class="container">
    <div class="regform">
       
        <form action="rsignup.php" method="post">
            <p class="logo">Food <b style='color:#3498DB;'>For All</b></p>
            
            <p id="heading">Create your account</p>
            
            <div class="input">
                <label class="textlabel" for="name">User name</label><br>
                
                <input type="text" id="name" name="name" required/>
             </div>
             <div class="input">
                <label class="textlabel" for="email">Email</label>
                <input type="email" id="email" name="email" required/>

                <!-- <label class="textlabel" for="phoneno">Phone no</label>
                <input type="text" id="phoneno" name="phoneno" > -->
         
                <!-- <label class="textlabel" for="password">Password</label>
                <input type="password" id="password" name="password" > -->
            
        
              

             </div>
             <label class="textlabel" for="password">Password</label>
             <div class="password">
              
                <input type="password" name="password" id="password" required/>
                <!-- <i class="fa fa-eye-slash" aria-hidden="true" id="showpassword"></i> -->
                <!-- <i class="bi bi-eye-slash" id="showpassword"></i>  -->
                <!-- <i class="uil uil-lock icon"></i> -->
                <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>                
			
             </div>
    
             <div class="radio">
                
                <input type="radio" name="gender" id="male" value="male" required/>
                <label for="male" >Male</label>
                <input type="radio" name="gender" id="female" value="female">
                <label for="female" >Female</label>

             </div>
             <div class="btn">
                <button type="submit" name="sign">Continue</button>
             </div>
            
           <!-- <button type="submit" style="background-color:white ;color: #000; margin-top:5px;  padding: 10px 25px;">
                 <img src="google.svg" style="width:22px" >
                 Continue With  Google </button>  -->
                
            <div class="signin-up">
                 <p style="font-size: 20px; text-align: center;">Already have an account? <a href="rsignin.php"> Sign in</a></p>
             </div>
         

        </form>
        </div>
        <!-- <div class="right">
            <img src="cover.jpg" alt="" width="800" height="700">
        </div> -->
       
    </div>
  

    <!-- <script src="login.js"></script> -->
    <script src="admin/delivery.js"></script>
       
</body>
</html>