<?php
session_start(); // Start the session
// Check if the form is submitted
if(isset($_POST['sign'])) {
    // Include your database connection file
    include 'connection.php'; // Replace 'connection.php' with your actual connection file

    // Retrieve form data and sanitize it
    $username = mysqli_real_escape_string($connection, $_POST['username']);
    $address = mysqli_real_escape_string($connection, $_POST['address']);
    $district = mysqli_real_escape_string($connection, $_POST['district']);
    $phone = mysqli_real_escape_string($connection, $_POST['phone']);
    $food_preference = isset($_POST['food_preference']) ? $_POST['food_preference'] : '';

    // Insert the data into the food_request table
    $insert_query = "INSERT INTO food_request (username, address, district, phone_number, food_preference) 
                     VALUES ('$username', '$address', '$district', '$phone', '$food_preference')";

    if(mysqli_query($connection, $insert_query)) {
      
        header("Location: request_done.php");
        exit(); // Prevent further execution
    } else {
        echo "Error: " . mysqli_error($connection);
    }

    // Close database connection
    mysqli_close($connection);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="loginstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f7f7f7;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
      }

      .container {
        width: 400px;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }

      .logo {
        font-size: 24px;
        font-weight: bold;
        color: #3498DB;
        margin-bottom: 20px;
        text-align: center;
      }

      #heading {
        font-size: 20px;
        margin-bottom: 20px;
        text-align: center;
      }

      .input {
        margin-bottom: 15px;
      }

      .textlabel {
        font-size: 16px;
        font-weight: bold;
      }

      input[type="text"],
      input[type="email"],
      select {
        width: calc(100% - 22px);
        padding: 10px;
        margin-top: 5px;
        margin-left: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
      }

      .food-preference {
        display: flex;
        justify-content: space-between;
        margin-left: 10px;
      }

      .food-preference label {
        display: block;
        margin-bottom: 10px;
        font-size: 16px;
      }

      .btn {
        text-align: center;
      }

      button[type="submit"] {
        background-color: #3498DB;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 12px 20px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s;
      }

      button[type="submit"]:hover {
        background-color: #2980b9;
      }

      .signin-up a {
        color: #3498db;
        text-decoration: none;
        font-weight: bold;
        transition: color 0.3s;
      }

      .signin-up a:hover {
        color: #2980b9;
      }
    </style>
</head>
<body>

    <div class="container">
        <p class="logo">Food <b>For All</b></p>
        <p id="heading">Food Request Form</p>
        <form action="rindex.php" method="post">
        <div class="input">
    <label class="textlabel" for="username">Username</label><br>
    <input type="text" id="username" name="username" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>" readonly required/>
</div>

            <div class="input">
                <label class="textlabel" for="address">Address</label><br>
                <input type="text" id="address" name="address" required/>
            </div>
            <div class="input">
                <label class="textlabel" for="district">District</label><br>
                <select id="district" name="district" required>
                    <option value="" disabled selected>Select District</option>
                    <option value="chennai">Chennai</option>
                    <option value="madurai">Madurai</option>
                    <option value="coimbatore">Coimbatore</option>
                </select>
            </div>
            <div class="input">
                <label class="textlabel" for="phone">Phone Number</label><br>
                <input type="text" id="phone" name="phone" required/>
            </div>
            <div class="input">
                <label class="textlabel" for="food_preference">Food Preference : </label><br>
                <div class="food-preference">
                    <label for="veg">
                        <input type="checkbox" id="veg" name="food_preference" value="vegetarian">
                        Vegetarian
                    </label>
                    <label for="non_veg">
                        <input type="checkbox" id="non_veg" name="food_preference" value="non-vegetarian">
                        Non-Vegetarian
                    </label>
                </div>
            </div>
            <div class="btn">
                <button type="submit" name="sign">Request Food</button>
            </div>
        </form>
    </div>

</body>
</html>
