<?php
session_start(); // Start the session

// Check if the form is submitted
if(isset($_POST['sign'])) {
    // Include your database connection file
    include 'connection.php';

    // Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];
    $_SESSION['email']=$email;
    // Prepare and execute SQL query to check if email exists in rsignup table
    $check_query = "SELECT * FROM rsignup WHERE email='$email'";
    $check_result = mysqli_query($connection, $check_query);

    // Check if query executed successfully
    if($check_result) {
        // Check if email exists in the table
        if(mysqli_num_rows($check_result) > 0) {
            // Fetch the user data
            $user_data = mysqli_fetch_assoc($check_result);

            // Verify the password
            if(password_verify($password, $user_data['password'])) {
                // Set session variables with the logged-in user's data
                $_SESSION['name'] = $user_data['username'];
                $_SESSION['email'] = $email;
                // Redirect user to dashboard or another page
                header("Location: rindex.php");
                exit(); // Prevent further execution
            } else {
                echo "Error: Incorrect password";
            }
        } else {
            echo "Error: Email not found";
        }
    } else {
        // If query execution fails, display an error message
        echo "Error: " . mysqli_error($connection);
    }

    // Close database connection
    mysqli_close($connection);
}
?>





















<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="loginstyle.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />

    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

</head>

<body>
    <style>
    .uil {

        top: 42%;
    }
    .signin-up {
      text-align: center;
      margin-top: 20px;
    }

    .signin-up p {
      font-size: 20px;
      margin-bottom: 0;
    }

    .signin-up a {
      color: #3498db; /* Blue color, you can change it */
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s;
    }

    .signin-up a:hover {
      color: #2980b9; /* Darker blue on hover */
    }
    </style>
    <div class="container">
        <div class="regform">

            <form action=" " method="post">

                <p class="logo" style="">Food <b style='color:#3498DB;'>For All</b></p>
                <p id="heading" style="padding-left: 1px;"> Welcome back ! <img src="" alt=""> </p>

                <div class="input">
                    <input type="email" placeholder="Email address" name="email" value="" required />
                </div>
                <div class="password">
                    <input type="password" placeholder="Password" name="password" id="password" required />

                    <!-- <i class="fa fa-eye-slash" aria-hidden="true" id="showpassword"></i> -->
                    <!-- <i class="bi bi-eye-slash" id="showpassword"></i> -->
                    <i class="uil uil-eye-slash showHidePw"></i>
                    <!-- <p class="error">Password don't match.</p> -->
                </div>


                <div class="btn">
                    <button type="submit" name="sign"> Sign in</button>
                </div>
                <div class="signin-up">
                    <p id="signin-up">Don't have an account? <a href="rsignup.php">Register</a></p>
                </div>
            </form>
        </div>


    </div>
    <script src="login.js"></script>
    <script src="admin/login.js"></script>
</body>

</html>
