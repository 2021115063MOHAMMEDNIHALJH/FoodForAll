<?php
    include "../connection.php";
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Received</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="../profile.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #92c3ff, #a1d8d0);
            /* Fallback color if gradients are not supported */
            background-color: #92c3ff; /* Fallback color */
            font-family: Arial, sans-serif;
        }
        header {
            background-color: #fff; /* White background for header */
            padding: 10px 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Shadow for header */
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            color: #3498db;
            font-weight: bold;
        }
        .nav-bar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .nav-bar ul li {
            margin-right: 20px;
        }
        .container {
            text-align: center;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: #333; /* Text color for better readability */
            /* Animation for twinkling border */
            animation: twinkling-border 3s infinite linear;
            margin: 20px;
        }
        .message {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .confirmation {
            font-size: 18px;
        }

        /* Keyframes for twinkling border animation */
        @keyframes twinkling-border {
            0% {
                border-color: #f0f, #f00, #00f, #ff0; /* Define your desired border colors */
            }
            25% {
                border-color: #f00, #00f, #ff0, #f0f; /* Change border colors at 25% */
            }
            50% {
                border-color: #00f, #ff0, #f0f, #f00; /* Change border colors at 50% */
            }
            75% {
                border-color: #ff0, #f0f, #f00, #00f; /* Change border colors at 75% */
            }
            100% {
                border-color: #f0f, #f00, #00f, #ff0; /* Change border colors at 100% */
            }
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Food <b style="color:#3498db">For All</b></div>
    <nav class="nav-bar">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="rprofile.php" class="active">Profile</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <div class="message">Your request is received!</div>
    <div class="confirmation">We'll try our best to fulfill your request.</div>
</div>

</body>
</html>
