<?php
    include "../connection.php";
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receiver Profile</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="../profile.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #92c3ff, #a1d8d0);
            /* Fallback color if gradients are not supported */
            background-color: #92c3ff; /* Fallback color */
            font-family: Arial, sans-serif;
        }
        .container {
            text-align: center;
            padding: 20px;
            margin-top: 50px; /* Adjust top margin as needed */
        }
        .profilebox {
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: #333; /* Text color for better readability */
            margin: 0 auto; /* Center the container horizontally */
            max-width: 500px; /* Set maximum width */
            height: auto; /* Let the height adjust based on content */
            overflow: auto; /* Add overflow for content exceeding height */
        }
        .headingline {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .info {
            text-align: left;
        }
        .info p {
            margin-bottom: 10px;
        }
        .logout-btn {
            display: block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #3498db;
            color: white;
            padding: 10px 15px; /* Adjusted padding */
            border-radius: 5px;
            max-width: 200px; /* Adjusted maximum width */
            margin: 0 auto; /* Center the button horizontally */
        }
        .logout-btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Food <b style="color:#3498db">For All</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="rprofile.php" class="active">Profile</a></li>
        </ul>
    </nav>
</header>

<script>
    hamburger = document.querySelector(".hamburger");
    hamburger.onclick = function() {
        navBar = document.querySelector(".nav-bar");
        navBar.classList.toggle("active");
    }
</script>

<div class="container">
    <div class="profilebox">
        <p class="headingline"><b>Profile</b></p>
        <!-- Display receiver's information -->
        <div class="info">
            <?php
            // Fetch receiver's information from the database
            $receiverId = $_SESSION['email'];
            $query = "SELECT * FROM rsignup WHERE email = ?";
            $stmt = mysqli_prepare($connection, $query);

            // Bind the parameter
            mysqli_stmt_bind_param($stmt, "s", $receiverId);

            // Execute the statement
            mysqli_stmt_execute($stmt);

            // Get the result
            $result = mysqli_stmt_get_result($stmt);

            // Fetch the receiver's information
            if ($result) {
                $row = mysqli_fetch_assoc($result);
                echo "<p><b>ID:</b> " . $row['id'] . "</p>";
                echo "<p><b>Username:</b> " . $row['username'] . "</p>";
                echo "<p><b>Email:</b> " . $row['email'] . "</p>";
                echo "<p><b>Gender:</b> " . $row['gender'] . "</p>";
            } else {
                echo "Error fetching receiver information: " . mysqli_error($connection);
            }
            ?>
        </div>

        <a href="../logout.php" class="logout-btn">Logout</a>
    </div>
</div>

</body>
</html>
