<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Display Session Variables</title>
</head>
<body>

<h1>Session Variables Display</h1>

<div>
    <p>Delivery Person ID: <?php echo $_SESSION['did']; ?></p>
    <p>Order ID: <?php echo $_SESSION['oid']; ?></p>
</div>

</body>
</html>
