<?php
ob_start(); 
// $connection = mysqli_connect("localhost:3307", "root", "");
// $db = mysqli_select_db($connection, 'demo');
 include("connect.php"); 
if($_SESSION['name']==''){
	header("location:signin.php");
}
?>
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>

    <!----======== CSS ======== -->
    <link rel="stylesheet" href="admin.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Admin Dashboard Panel</title> 
    <style>
        ::placeholder {
        /* Change the color of the placeholder text */
        color: white; /* Replace #999 with your desired color */
        text-align:center;
    }
    </style>
<?php
 $connection=mysqli_connect("localhost","root","admin1234$");
 $db=mysqli_select_db($connection,'demo');
 


?>
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <!--<img src="images/logo.png" alt="">-->
            </div>

            <span class="logo_name">ADMIN</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="#">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <!-- <li><a href="#">
                    <i class="uil uil-files-landscapes"></i>
                    <span class="link-name">Content</span>
                </a></li> -->
                <li><a href="analytics.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">Analytics</span>
                </a></li>
                <li><a href="donate.php">
                    <i class="uil uil-heart"></i>
                    <span class="link-name">Donates</span>
                </a></li>
                <li><a href="feedback.php">
                    <i class="uil uil-comments"></i>
                    <span class="link-name">Feedbacks</span>
                </a></li>
                <li><a href="adminprofile.php">
                    <i class="uil uil-user"></i>
                    <span class="link-name">Profile</span>
                </a></li>
                <!-- <li><a href="#">
                    <i class="uil uil-share"></i>
                    <span class="link-name">Share</span>
                </a></li> -->
            </ul>
            
            <ul class="logout-mode">
                <li><a href="../logout.php">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li>

                <li class="mode">
                    <a href="#">
                        <i class="uil uil-moon"></i>
                    <span class="link-name">Dark Mode</span>
                </a>

                <div class="mode-toggle">
                  <span class="switch"></span>
                </div>
            </li>
            </ul>
        </div>
    </nav>

    <section class="dashboard">
        
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <!-- <p>Food Donate</p> -->
            <p  class ="logo" >Food <b style="color: #3498DB; ">For All</b></p>
             <p class="user"></p>
            <!-- <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div> -->
            
            <!--<img src="images/profile.jpg" alt="">-->
        </div>

        <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="uil uil-tachometer-fast-alt"></i>
                    <span class="text">Dashboard</span>
                </div>

                <div class="boxes">
                    <div class="box box1">
                        <i class="uil uil-user"></i>
                        <!-- <i class="fa-solid fa-user"></i> -->
                        <span class="text">Total users</span>
                        <?php
                           $query="SELECT count(*) as count FROM  login";
                           $result=mysqli_query($connection, $query);
                           $row=mysqli_fetch_assoc($result);
                         echo "<span class=\"number\">".$row['count']."</span>";
                        ?>
                        <!-- <span class="number">50,120</span> -->
                    </div>
                    <div class="box box2">
                        <i class="uil uil-comments"></i>
                        <span class="text">Feedbacks</span>
                        <?php
                           $query="SELECT count(*) as count FROM  user_feedback";
                           $result=mysqli_query($connection, $query);
                           $row=mysqli_fetch_assoc($result);
                         echo "<span class=\"number\">".$row['count']."</span>";
                        ?>
                        <!-- <span class="number">20,120</span> -->
                    </div>
                    <div class="box box3">
                        <i class="uil uil-heart"></i>
                        <span class="text">Total donates</span>
                        <?php
                           $query="SELECT count(*) as count FROM food_donations";
                           $result=mysqli_query($connection, $query);
                           $row=mysqli_fetch_assoc($result);
                         echo "<span class=\"number\">".$row['count']."</span>";
                        ?>
                        <!-- <span class="number">10,120</span> -->
                    </div>
                </div>
            </div>

            <div class="activity">
                <div class="title">
                    <i class="uil uil-clock-three"></i>
                    <span class="text">Possible Donations</span>
                </div>
            <div class="get">
            <?php

$loc= $_SESSION['location'];

// Define the SQL query to fetch unassigned orders
$sql = "SELECT * FROM food_donations WHERE assigned_to IS NULL and location=\"$loc\" and date >= DATE_SUB(NOW(), INTERVAL 4 HOUR)";

// Execute the query
$result=mysqli_query($connection, $sql);
$id=$_SESSION['Aid'];

// Check for errors
if (!$result) {
    die("Error executing query: " . mysqli_error($conn));
}

// Fetch the data as an associative array
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// If the delivery person has taken an order, update the assigned_to field in the databasE
// If the delivery person has taken an order, update the assigned_to field in the database
if (isset($_POST['food']) && isset($_POST['delivery_person_id'])) {
    $recvaddr = $_POST['receiver-addr']; // Get the value from the form input

    $order_id = $_POST['order_id'];
    $delivery_person_id = $_POST['delivery_person_id'];
    $sql = "SELECT * FROM food_donations WHERE Fid = $order_id AND assigned_to IS NOT NULL";
    $result = mysqli_query($connection, $sql);

    if (mysqli_num_rows($result) > 0) {
        // Order has already been assigned to someone else
        die("Sorry, this order has already been assigned to someone else.");
    }

    // Update the 'assigned_to' column
    $sql = "UPDATE food_donations SET assigned_to = $delivery_person_id WHERE Fid = $order_id";
    $result = mysqli_query($connection, $sql);
    if (!$result) {
        die("Error assigning order: " . mysqli_error($conn));
    }

    // Update the 'recv_addr' column
    $sql = "UPDATE food_donations SET recv_addr = '$recvaddr' WHERE Fid = $order_id";
    $result = mysqli_query($connection, $sql);
    if (!$result) {
        die("Error updating receiver address: " . mysqli_error($conn));
    }

    // Reload the page to prevent duplicate assignments
    header('Location: ' . $_SERVER['REQUEST_URI']);
    // exit;
    ob_end_flush();
}

// mysqli_close($conn);


?>

<!-- Display the orders in an HTML table -->
<div class="table-container">
         <!-- <p id="heading">donated</p> -->
         <div class="table-wrapper">
        <table class="table">
        <thead>
        <tr>
            <th >Name</th>
            <th>food</th>
            <th>Category</th>
            <th>phoneno</th>
            <th>Quantity</th>
            <th>Recv-addr</th>
            <th>Action</th>
            <!-- <th>Action</th> -->
         
          
           
        </tr>
        </thead>
       <tbody>

        <?php foreach ($data as $row) { ?>
        <?php    echo "<tr><td data-label=\"name\">".$row['name']."</td><td data-label=\"food\">".$row['food']."</td><td data-label=\"category\">".$row['category']."</td><td data-label=\"phoneno\">".$row['phoneno']."</td><td data-label=\"quantity\">".$row['quantity']."</td>";
?>
        
            <!-- <td><?= $row['Fid'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['address'] ?></td> -->
            <form method="post" action=" ">
            <td><input type="text" name="receiver-addr" id="receiveaddr" placeholder="recv" size="10"></td>
            <td data-label="Action" style="margin:auto">
                <?php if ($row['assigned_to'] == null) { ?>
                    
                        <input type="hidden" name="order_id" value="<?= $row['Fid'] ?>">
                        <input type="hidden" name="delivery_person_id" value="<?= $id ?>">
                        
                        <button type="submit" name="food">Get Food</button>
                    </form>
                <?php } else if ($row['assigned_to'] == $id) { ?>
                    Order assigned to you
                <?php } else { ?>
                    Order assigned to another delivery person
                <?php } ?>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

            </div>
            <div class="activity">
                <div class="title">
                    <i class="uil uil-clock-three"></i>
                    <span class="text">Donations that should be redirected to farm</span>
                </div>
            <div class="get">
            <?php

$loc= $_SESSION['location'];

// Define the SQL query to fetch unassigned orders
$sql = "SELECT * FROM food_donations WHERE assigned_to IS NULL and location=\"$loc\" and date <= DATE_SUB(NOW(), INTERVAL 4 HOUR)";

// Execute the query
$result=mysqli_query($connection, $sql);
$id=$_SESSION['Aid'];

// Check for errors
if (!$result) {
    die("Error executing query: " . mysqli_error($conn));
}

// Fetch the data as an associative array
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// If the delivery person has taken an order, update the assigned_to field in the database
if (isset($_POST['food']) && isset($_POST['delivery_person_id'])) {

    
    $order_id = $_POST['order_id'];
    $delivery_person_id = $_POST['delivery_person_id'];
    $sql = "SELECT * FROM food_donations WHERE Fid = $order_id AND assigned_to IS NOT NULL";
    $result = mysqli_query($connection, $sql);

    if (mysqli_num_rows($result) > 0) {
        // Order has already been assigned to someone else
        die("Sorry, this order has already been assigned to someone else.");
    }



    $sql = "UPDATE food_donations SET assigned_to = $delivery_person_id WHERE Fid = $order_id";
    // $result = mysqli_query($conn, $sql);
    $result=mysqli_query($connection, $sql);


    if (!$result) {
        die("Error assigning order: " . mysqli_error($conn));
    }

    // Reload the page to prevent duplicate assignments
    header('Location: ' . $_SERVER['REQUEST_URI']);
    // exit;
    ob_end_flush();
}
// mysqli_close($conn);


?>

<!-- Display the orders in an HTML table -->
<div class="table-container">
         <!-- <p id="heading">donated</p> -->
        <div class="table-wrapper">
        <table class="table">
        <thead>
        <tr>
            <th >Name</th>
            <th>food</th>
            <th>Category</th>
            <th>phoneno</th>
            <th>Date</th>
            <th>RECV-ADDR</th>
            <th>Quantity</th>
            <th>ACTION</th>
            <!-- <th>Action</th> -->
         
          
           
        </tr>
        </thead>
       <tbody>

        <?php foreach ($data as $row) { ?>
        <?php    echo "<tr><td data-label=\"name\">".$row['name']."</td><td data-label=\"food\">".$row['food']."</td><td data-label=\"category\">".$row['category']."</td><td data-label=\"phoneno\">".$row['phoneno']."</td><td data-label=\"date\">".$row['date']."</td><td data-label=\"Address\">".$row['address']."</td><td data-label=\"quantity\">".$row['quantity']."</td>";
?>
        
            <!-- <td><?= $row['Fid'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['address'] ?></td> -->
            <form method="post" action=" ">
            <td><input type="text" id="receiveaddr" name="receiver-addr" placeholder="recv" size="10"></td>
            <td data-label="Action" style="margin:auto">
                <?php if ($row['assigned_to'] == null) { ?>
                    
                        <input type="hidden" name="order_id" value="<?= $row['Fid'] ?>">
                        <input type="hidden" name="delivery_person_id" value="<?= $id ?>">
                        <button type="submit" name="food">Get Food</button>
                    </form>
                <?php } else if ($row['assigned_to'] == $id) { ?>
                    Order assigned to you
                <?php } else { ?>
                    Order assigned to another delivery person
                <?php } ?>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

            </div>
            <div class="activity">  
                <div class="title">
                        <i class="uil uil-clock-three"></i>
                        <span class="text">Receiver Details</span>
                    </div>
            <div class='get'>

<div class="table-container">
	<div class="table-wrapper">
    <table class="table">
	<thead>
	<tr>
		<th>ID</th>
		<th>Username</th>
		<th>Address</th>
		<th>District</th>
		<th>Phone Number</th>
		<th>Food Preference</th>
		<th>Action</th>
    </tr>
    <!--<tr>
        <td><?php echo isset($row['id']) ? $row['id'] : ''; ?></td>
        <td><?php echo isset($row['username']) ? $row['username'] : ''; ?></td>
        <td><?php echo isset($row['address']) ? $row['address'] : ''; ?></td>
        <td><?php echo isset($row['district']) ? $row['district'] : ''; ?></td>
        <td><?php echo isset($row['phone_number']) ? $row['phone_number'] : ''; ?></td>
        <td><?php echo isset($row['food_preference']) ? $row['food_preference'] : ''; ?></td>
        <td><button class="copy-address-btn" data-clipboard-text="<?php echo isset($row['address']) ? $row['address'] : ''; ?>" size="10">Copy Address</button></td>
        <td>
            <form method="post" action="">
                <input type="hidden" name="request_id" value="<?php echo isset($row['id']) ? $row['id'] : ''; ?>">
                    <button type="submit" name="satisfy_request" size="10">Satisfy Request</button>
                </form>
        </td>
    </tr>-->
    </thead>
    <tbody>
    <?php
// Retrieve receiver details from the 'food_request' table
$query = "SELECT * FROM food_request where district='$loc'";
$result = mysqli_query($connection, $query);

// Check if there are any results
if (mysqli_num_rows($result) > 0) {
    //die("Sorry, this order has already been assigned to someone else.");


    // Display receiver details in an HTML table
  
    /*echo '<div class="table-container">';
    echo '<div class="table-wrapper">';
    echo '<table class="table">';
    echo '<table>';
    echo '<thead>';
    echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>Username</th>';
    echo '<th>Address</th>';
    echo '<th>District</th>';
    echo '<th>Phone Number</th>';
    echo '<th>Food Preference</th>';
    echo '<th>Action</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';*/


    //$data = array();
    // Loop through each row of data
        while ($row = mysqli_fetch_assoc($result)) {
            /*echo '<tr>';
            // Add checks to ensure array keys exist before accessing them
            echo '<td>' . (isset($row['id']) ? $row['id'] : '') . '</td>';
            echo '<td>' . (isset($row['username']) ? $row['username'] : '') . '</td>';
            echo '<td>' . (isset($row['address']) ? $row['address'] : '') . '</td>';
            echo '<td>' . (isset($row['district']) ? $row['district'] : '') . '</td>';
            echo '<td>' . (isset($row['phone_number']) ? $row['phone_number'] : '') . '</td>';
            echo '<td>' . (isset($row['food_preference']) ? $row['food_preference'] : '') . '</td>';
            echo '<td><button class="copy-address-btn" data-clipboard-text="' . $row['address'] . '" size="10">Copy Address</button></td>';

            echo '<td>';
            // Add a button to satisfy the request and delete the corresponding row
            echo '<form method="post" action="">';
            echo '<input type="hidden" name="request_id" value="' . $row['id'] . '">';
            echo '<button type="submit" name="satisfy_request" size="10">Satisfy Request</button>';
            //echo '<input type="submit"  name="satisfy_request" placeholder="Satisfy Request" size="10">';
            echo '</form>';
            echo '</td>';
            echo '</tr>';*/

            // Fetch the data as an associative array

            //$data[] = $row;
            echo "<tr><td data-label=\"id\">".$row['id']."</td><td data-label=\"username\">".$row['username']."</td><td data-label=\"address\">".$row['address']."</td><td data-label=\"district\">".$row['district']."</td><td data-label=\"phone number\">".$row['phone_number']."</td><td data-label=\"food preference\">".$row['food_preference']."</td><td><button class=\"copy-address-btn\" data-clipboard-text=".$row['address']." size=\"10\">Copy Address</button></td>
            <td data-label=\"Action\" style=\"margin:auto\">";
            /*echo "<form method=\"post\" action=\"\">
            <td>
                <?php if (isset($row['id'])) { ?>
                    <input type=\"hidden\" name=\"request_id\" value=\"<?php echo $row['id']; ?>\">
                    <button type=\"submit\" name=\"satisfy_request\" size=\"10\">Satisfy Request</button>
                <?php } ?>
            </td>
        </form>";*/
        echo "<form method=\"post\" action=\"\">";
        if (isset($row['id'])) {
            echo "<input type=\"hidden\" name=\"request_id\" value=\"" . $row['id'] . "\">
                            <button type=\"submit\" name=\"satisfy_request\" size=\"10\">Satisfy Request</button>";
        }
        echo "
                </form>";

            
        }



    /*echo '</tbody>';

    echo '</table>';
    echo '</div>';
    echo '</div>';*/
}
else {
    // No results found
    echo '<p>No requests found.</p>';
}


// Check if the "Satisfy Request" button is clicked
if (isset($_POST['satisfy_request'])) {
    $request_id = $_POST['request_id'];

    // Delete the corresponding row from the 'food_request' table
    $delete_query = "DELETE FROM food_request WHERE id = $request_id";
    $delete_result = mysqli_query($connection, $delete_query);

    if ($delete_result) {
        // Row deleted successfully
        echo '<script>alert("Request satisfied successfully.");</script>';
        // Reload the page to reflect changes
        echo '<script>window.location.href = "admin.php";</script>';
    } else {
        // Error occurred while deleting the row
        echo '<script>alert("Error satisfying request.");</script>';
    }
}
      
            ?>
         
            
                </tbody>
            </table>
        </div>
        </div>  
</section>

<script>
        // Initialize Clipboard.js
        var clipboard = new ClipboardJS('.copy-address-btn');

        // Show success message when address is copied
        clipboard.on('success', function(e) {
            alert('Address copied to clipboard: ' + e.text);
            e.clearSelection();
        });

        // Show error message if copying fails
        clipboard.on('error', function(e) {
            alert('Failed to copy address to clipboard.');
        });
    </script>
    <script>
    // Get the "receiveaddr" input element
    var receiveAddrInput = document.getElementById("receiveaddr");

    // Add an event listener for the "click" event
    receiveAddrInput.addEventListener("click", function() {
        // Check if there is any text copied to the clipboard
        if (navigator.clipboard) {
            navigator.clipboard.readText().then(function(copiedText) {
                // If text is copied, paste it into the input field
                if (copiedText) {
                    receiveAddrInput.value = copiedText;
                }
            }).catch(function(err) {
                console.error('Failed to read clipboard contents: ', err);
            });
        }
    });
</script>
    <script src="admin.js"></script>
</body>
</html>
