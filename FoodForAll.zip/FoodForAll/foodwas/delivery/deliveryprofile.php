
<?php
include("dlogin.php");
// if($_SESSION['loggedin']==true){
//     header("location:loginindex.html");
// }
include '../connection.php';
if($_SESSION['name']==''){
	header("location: deliverysignup.php");
}

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Document</title> -->
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="../profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
          body {
            /* background-color: #20cd79; */
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
        }

        .cover {
            width: 100%;
            height: 500px;
            background: url('profilecover2.jpg') no-repeat;
            background-size: cover;
            display: grid;
            place-items: center;
            padding-top: 8rem;
        }

        .profilebox {
            text-align: center;
            width: 700px;
            height: 900px;
            margin: 20px auto;
            /* background-color: rgba(90, 255, 208, 0.713); */
            /* box-shadow: 0 .5rem 1rem rgba(0,0,0.1); */
            color: black;
            padding: 10px 20px 20px 20px;
            font-size: 20px;
            /* border-radius: 30px; */
        }

        .info {
            /* font-family: 'Times New Roman', Times, serif; */
            text-align: left;
            padding: 10px;
        }

        .table-container {
            padding: 0;
            margin: 20px auto 10px;
            /* border: 1px solid; */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            /* border-radius: 10px; */
        }

        .table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0px;
        }

        th {
            position: sticky;
            top: 0px;
            background-color: #3498db;
        }

        th, td {
            /* border: 1px solid #12121385; */
        }

        .table-wrapper {
            max-height: 130px;
            overflow-y: scroll;
        }

        .table thead tr th {
            font-size: 14px;
            font-weight: medium;
            letter-spacing: 0.35px;
            opacity: 1;
            padding: 12px;
            vertical-align: top;
        }

        /* for phone */
        @media (max-width: 767px) {
            .cover {
                width: auto;
                height: auto;
                background: url('profilecover1.jpg') no-repeat;
                background-size: cover;
                display: grid;
                place-items: center;
                padding-top: 8rem;
            }
            
            .cover img {
                width: 100%;
                height: auto;
            }

            .profilebox {
                width: 350px;
                font-size: 14px;
                height: 600px;
                border-radius: 30px;
            }

            .table thead tr th {
                font-size: 14px;
                font-weight: medium;
                letter-spacing: 0.35px;
                opacity: 1;
                padding: 5px;
            }
        }

        .headingline {
            font-size: 28px;
            text-align: center;
            align-items: center;
        }

        .table-container .table th {
            font-size: 18px; /* Adjust the size as needed */
        }
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #f2f2f2;
            color: #333;
        }

        .cover {
            width: 100%;
            height: 500px;
            background: url('profilecover2.jpg') no-repeat;
            background-size: cover;
            display: grid;
            place-items: center;
            padding-top: 8rem;
        }

        .profilebox {
            text-align: center;
            width: 70%;
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
        }

        .info table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .info th, .info td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .info th {
            background-color: #37db8c;
            color: #fff;
        }

        .info tr:hover {
            background-color: #3498db;
        }

        .headingline {
            font-size: 28px;
            text-align: center;
            align-items: center;
        }
        a[href="../logout.php"] {
    float: left;
    margin-top: 6px;
    border-radius: 5px;
    background-color: #3498db;
    color: white;
    padding: 10px;
    padding-left: 20px;
    padding-right: 20px;
    transition: all 0.3s ease-in-out; /* Add transition property */
}

a[href="../logout.php"]:hover {
    padding-left: 15px; /* Adjust the padding on hover */
    padding-right: 15px; /* Adjust the padding on hover */
}
    </style>
</head>
<body>
<header>
        <div class="logo">Food <b style="color:#3498db">For All</b></div>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="nav-bar">
            <ul>
                <li><a href="delivery.php">Home</a></li>
                <li><a href="about.html" >About</a></li>
                <li><a href="contact.html"  >Contact</a></li>
                <li><a href="deliveryprofile.php"  class="active">Profile</a></li>
            </ul>
        </nav>
    </header>
    <script>
        hamburger=document.querySelector(".hamburger");
        hamburger.onclick =function(){
            navBar=document.querySelector(".nav-bar");
            navBar.classList.toggle("active");
        }
    </script>
  
    
    



    <div class="profile">
    <!-- <section class="cover" >
        
        </section>
     -->
        <div class="profilebox" style="">
          
            <p class="headingline" style="text-align: left;font-size:30px;"> <img src="" alt="" style="width:40px; height:  height: 25px;; padding-right: 10px; position: relative;" ><b>Profile</b></p>
<!--             
            <img src="user.png" alt="" style="  width: 90px;
            height: 90px;
            /* border-radius:50% ;  */
            display: block;
            margin-left: auto;
            margin-right: auto;
            padding-top: 10px;
             /* border: 1px solid #06C167; */
            ">
            <br> -->
              <!-- <p style="font-size: 28px;">welcome</p> -->
              <!-- <p style="color: #06C167;">username</p> -->
              <br>
              <div class="info" style="padding-left:10px;">
              <p style=""><b>Name  :</b><?php echo"". $_SESSION['name'] ;?> </p><br>
              <p style=""><b>Email :</b><?php echo"". $_SESSION['email'];?> </p><br>
              <?php
               
               $Did = $_SESSION['Did'];
               $query = "SELECT COUNT(*) AS rowCount FROM food_donations WHERE delivery_by = ?";
               $stmt = mysqli_prepare($connection, $query);
               $city=$_SESSION['city'];
               // Bind the parameter
               mysqli_stmt_bind_param($stmt, "i", $Did);
               
               // Execute the statement
               mysqli_stmt_execute($stmt);
               
               // Get the result
               $result = mysqli_stmt_get_result($stmt);
               
               // Fetch the count
               if ($result) {
                   $row = mysqli_fetch_assoc($result);
                   $rowCount = $row['rowCount'];
                   echo "<p style=''><b>No of Deliveries :</b> $rowCount</p><br>";
                   echo "<p style=''><b>city : </b>$city</p><br>";

               } else {
                   echo "Error fetching count: " . mysqli_error($connection);
               }
               
               ?>
               
               



              <a href="../logout.php" style="float: left;margin-top: 6px ;border-radius:5px; background-color:#3498db;; color: white;padding: ;padding-left: 10px;padding-right: 10px;">Logout</a>
              </div>
              <br>
              <br>

            
            
         <hr>
         <br>
  
         <p class="heading"><b>Your deliveries</b></p>
         <!-- <p class="" style="font-family: 'Times New Roman', Times, serif; font-size: 20px;">Your donations</p><br> -->
         <!-- <img src="profilecover1.jpg" alt="" width='100%' height='auto'> -->
   <div class="table-container">
         <!-- <p id="heading">donated</p> -->
         <div class="table-wrapper">
        <table class="table">
        <thead>
        <tr>
            <th>Donor name </th>
            <th>Food</th>
            <th>Type</th>
            <th>Category</th>
            <th>Location</th>
        </tr>
        </thead>
       <tbody>
        

         <?php
        $Did=$_SESSION['Did'];
        $query="select * from food_donations where delivery_by=$Did";
        $result=mysqli_query($connection, $query);
        if($result==true){
            while($row=mysqli_fetch_assoc($result)){
                echo "<tr><td>".$row['name']."</td><td>".$row['food']."</td><td>".$row['type']."</td><td>".$row['category']."</td><td>".$row['location']."</td></tr>";

             }
          }
       ?> 
        

 

    
     

    </div>


   
    
    
</body>
</html>